/*
DDM4.h - Library for driving the DDM4 4 digit seven segment display unit
Created by M P KYTE, August 16th, 2017.



*/
//#ifndef DDM4_h
//#define DDM4_h

#include <Arduino.h>
#include <SPI.h>

class DDM4
{
public:
DDM4(); // declare constructor
DDM4(int loadPin); // declare constructor

void writeDDM4(int value,int dp); // function declaration
byte getSegs (int value); // function declaration
void loadDDM4(); // function declaration
void initDDM4(); // function declaration



private:
int _loadPin;
const byte ZERO = 0b01111110;
const byte ONE = 0b00011000;
const byte TWO = 0b10110110;
const byte THREE =0b10111100;
const byte FOUR = 0b11011000;
const byte FIVE = 0b11101100;
const byte SIX = 0b11001110;
const byte SEVEN = 0b00111000;
const byte EIGHT = 0b11111110;
const byte NINE = 0b11111000;
byte numbers[10] = {ZERO,ONE,TWO,THREE,FOUR,FIVE,SIX,SEVEN,EIGHT,NINE}; // INITIALISE SEVEN SEG ARRAY

byte initARRAY[6] = {0b00100000,0b00010000,0b00001000,0b00000100,0b00000010,0b01000000};

int _digit1;
int _digit2;
int _digit3;
int _digit4;

};
