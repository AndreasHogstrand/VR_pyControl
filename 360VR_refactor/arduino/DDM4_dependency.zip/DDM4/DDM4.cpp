/*
DDM4.cpp - Library for driving a DDM4 4 digit display.
Created by M P KYTE, August 16th, 2017.
two versions are available one that defaults pin 49 for load function and the other that is specified by the calling programme
*/
#include <Arduino.h>
#include <DDM4.h>

DDM4::DDM4() // default object
{
_loadPin = 49;
pinMode(_loadPin,OUTPUT);
digitalWrite(_loadPin,LOW);

}

DDM4::DDM4(int loadPin) // specify you own pin
{
_loadPin = loadPin;
pinMode(_loadPin,OUTPUT);
digitalWrite(_loadPin, LOW);

}

byte DDM4::getSegs (int value)
{
if (value > 9)
{
return (0b00000000);
}
else
{
return (numbers[value]);
}
}



void DDM4::loadDDM4()
{
digitalWrite(_loadPin,HIGH);
delayMicroseconds(10);
digitalWrite(_loadPin,LOW);
}

void DDM4::initDDM4()
{
SPI.begin();
SPI.beginTransaction(SPISettings(500000, LSBFIRST, SPI_MODE2)); // 500 kHz max
int n;
int i;
for (i=0;i<3;i++)
{

for (n=0;n<6;n++)
{
SPI.transfer(initARRAY[n]); // Least Sig DIGIT
SPI.transfer(initARRAY[n]);
SPI.transfer(initARRAY[n]);
SPI.transfer(initARRAY[n]); // Most Sig DIGIT



loadDDM4();
delay(80);
}
}

SPI.transfer(0b00000000); // Least Sig DIGIT
SPI.transfer(0b00000000);
SPI.transfer(0b00000000);
SPI.transfer(0b00000000); // Most Sig DIGIT



loadDDM4();
SPI.endTransaction();
}

void DDM4::writeDDM4(int value, int dp)
{
byte point1;
byte point2;
byte point3;
byte point4;

switch (dp){

case 1:
point1 = 1;
point2 = 0;
point3 = 0;
point4 = 0;
break;

case 2:
point1 = 0;
point2 = 1;
point3 = 0;
point4 = 0;
break;

case 3:
point1 = 0;
point2 = 0;
point3 = 1;
point4 = 0;
break;

case 4:
point1 = 0;
point2 = 0;
point3 = 0;
point4 = 1;
break;

default:
point1 = 0;
point2 = 0;
point3 = 0;
point4 = 0;
break;

}


SPI.begin();
SPI.beginTransaction(SPISettings(500000, LSBFIRST, SPI_MODE2)); // 500 kHz max

_digit1 = value%10; // break value down into 4 digits
_digit2 = ((value/10)%10);
_digit3 = ((value/100)%10);
_digit4 = ((value/1000)%10);

if (_digit4 == 0) // implement leading zero blanking
{
_digit4 = 10; // overload value of digit to return blank on getSeg
if (_digit3 == 0 && _digit4 == 10 )
{
_digit3 =10; // overload value of digit to return blank on getSeg
}
if (_digit2 == 0 && _digit3 == 10 && _digit4 == 10)
{
_digit2 = 10; // overload value of digit to return blank on getSeg
}
}




SPI.transfer(point1+getSegs(_digit1)); // Least Sig DIGIT
SPI.transfer(point2+getSegs(_digit2));
SPI.transfer(point3+getSegs(_digit3));
SPI.transfer(point4+getSegs(_digit4)); // Most Sig DIGIT

loadDDM4();

SPI.endTransaction();



}