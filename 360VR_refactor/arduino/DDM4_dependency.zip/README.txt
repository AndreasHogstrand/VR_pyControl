DDM4 is the library to use the 7segments diplay

To install, copy the folder DDM4 into Documents/Arduino/libraries